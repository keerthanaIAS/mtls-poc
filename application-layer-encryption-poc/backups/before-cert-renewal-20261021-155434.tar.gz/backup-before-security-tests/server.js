const https = require('https');
const fs = require('fs');
const crypto = require('crypto');

const read = (name) =>
  fs.readFileSync(`${__dirname}/../certs/${name}`);

const payloadPrivateKey = read('payload-private.pem');

function decryptPayload(envelope) {
  const key = crypto.privateDecrypt(
    {
      key: payloadPrivateKey,
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
      oaepHash: 'sha256'
    },
    Buffer.from(envelope.encryptedKey, 'base64')
  );

  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    key,
    Buffer.from(envelope.iv, 'base64')
  );

  decipher.setAuthTag(Buffer.from(envelope.authTag, 'base64'));

  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(envelope.ciphertext, 'base64')),
    decipher.final()
  ]);

  return JSON.parse(plaintext.toString('utf8'));
}

function send(res, status, data) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(data));
}

const server = https.createServer({
  key: read('internal.key'),
  cert: read('internal.crt'),
  ca: read('ca.crt'),
  requestCert: true,
  rejectUnauthorized: true,
  minVersion: 'TLSv1.2'
}, (req, res) => {
  if (req.socket.getPeerCertificate().subject?.CN !== 'gateway') {
    return send(res, 403, { error: 'Gateway identity required' });
  }

  if (req.method !== 'POST' ||
      !['/fund-transfer', '/balance', '/refund'].includes(req.url)) {
    return send(res, 404, { error: 'Route not found' });
  }

  let body = '';
  req.on('data', chunk => {
    body += chunk;
    if (body.length > 100_000) req.destroy();
  });

  req.on('end', () => {
    try {
      const envelope = JSON.parse(body);
      const data = decryptPayload(envelope);

      console.log(`\nAuthenticated gateway: gateway`);
      console.log(`Operation: ${req.url}`);
      console.log('Decrypted sample payload:', data);

      // Simulated responses only. No real transactions are executed.
      if (req.url === '/balance') {
        return send(res, 200, {
          success: true,
          operation: 'balance',
          availableBalance: 5000,
          currency: 'INR',
          simulated: true
        });
      }

      if (req.url === '/fund-transfer') {
        if (!(Number(data.amount) > 0)) {
          return send(res, 400, { error: 'Invalid amount' });
        }

        return send(res, 200, {
          success: true,
          operation: 'fund-transfer',
          reference: crypto.randomUUID(),
          simulated: true
        });
      }

      if (req.url === '/refund') {
        if (!(Number(data.amount) > 0)) {
          return send(res, 400, { error: 'Invalid amount' });
        }

        return send(res, 200, {
          success: true,
          operation: 'refund',
          reference: crypto.randomUUID(),
          simulated: true
        });
      }
    } catch (err) {
      console.error('Request rejected:', err.message);
      return send(res, 400, {
        error: 'Invalid or tampered encrypted payload'
      });
    }
  });
});

server.listen(9443, '127.0.0.1', () => {
  console.log('Internal banking service listening on https://127.0.0.1:9443');
  console.log('Requires gateway mTLS certificate.');
});
